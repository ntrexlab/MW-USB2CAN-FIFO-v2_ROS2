#include <stdio.h>
#include "CAN_Access.h"
#include <semaphore.h>


void SendCanMessage (long h)
{
	for(int i=0; i<10; i++)
	{
		long sid = i;

		unsigned char sdata[8] = { 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, (unsigned char)i, 0x11 };

		int ret1 = CAN_Send (h, sid, 8,  (char *)sdata, 0, 0);
		if (!ret1) {
			printf ("Send failed.\n");
		}
	}
	for(int i=10; i>0; i--)
	{
		long sid = i;

		unsigned char sdata[8] = { (unsigned char)i, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0xAA, 0x11 };

		int ret1 = CAN_Send (h, sid, 8,  (char *)sdata, 0, 0);
		if (!ret1) {
			printf ("Send failed.\n");
		}
	}
}

void RecvCanMessage (long h)
{
	char rdata[8] = { 0, 0, 0, 0, 0, 0, 0, 0 };
	long rid;
	int rlen, ext, rtr;

	// �����͸� �����Ѵ�.
	int ret = CAN_Recv (h, &rid, &rlen, rdata, &ext, &rtr);
	if (ret) {
		#if 1
			printf ("Recv: [%d] %02X %02X %02X %02X %02X %02X %02X %02X (%d)\n",
			rid, (int)(unsigned char)rdata[0], (int)(unsigned char)rdata[1], 
			(int)(unsigned char)rdata[2], (int)(unsigned char)rdata[3], 
			(int)(unsigned char)rdata[4], (int)(unsigned char)rdata[5], 
			(int)(unsigned char)rdata[6], (int)(unsigned char)rdata[7], 
			rlen);
			#endif
	}
}

int main(void)
{
	long bitrate;
	unsigned long filterID, filterMask;
	int startupTransferMode, busOffRecovery;
	sem_t hEvent;
	struct timespec ts;

	clock_gettime(CLOCK_REALTIME, &ts);
	ts.tv_sec += 1;

   int noDevice = CAN_Fifo_ScanSerialNumber ();
	if (noDevice <= 0) return -1;

	for (int i=0; i<noDevice; i++) {
		const char *serialNumber = CAN_Fifo_GetSerialNumber (i);
		printf ("%s\n", serialNumber);
	}

	long h = CAN_OpenFifo (CAN_Fifo_GetSerialNumber (0));

	if (h < 0) { 
		printf ("USB2CAN open failed.\n");
		return -1;
	}

	while(true)
	{
		int result = CAN_GetConfig(h, &bitrate, &filterID, &filterMask, &startupTransferMode, &busOffRecovery);

		if(result == true) break;
	}


	printf("USB2CAN (FIFO) \r\n");
	printf("bitrate : %ld\r\n", bitrate);
	printf("filterID : %d\r\n", filterID);
	printf("filterMask : %d\r\n", filterMask);
	printf("startupTransferMode : %d\r\n", startupTransferMode);
	printf("busOffRecovery : %d\r\n", busOffRecovery);

	sem_init(&hEvent, 1, 0);

	CAN_SetRxEventNotification(h, &hEvent);

	while(true)
	{
		int result = CAN_SetTransferMode (h, 1);

		if(result == true) break;
	}
	
	while(true)
	{
		SendCanMessage (h);

		int rx_count = CAN_CountRxQueue (h);

		if (rx_count > 0) {

			RecvCanMessage (h);
		}
		else{
			int result = sem_timedwait (&hEvent,&ts);

			if(!result) RecvCanMessage (h);
		}
	}
	CAN_Close (h);

	return 0;
}