#pragma once
#include <deque>
#include <vector>
#include "SerialInterface.h"
#include "Definition.h"
#include "WinTypes.h"
#include <string.h>
#include <unistd.h>

using namespace std;

struct sFtdiInfo {
	int Index;
	int ID;
	char SerialNumber[16];
	char Description[64];
	void *handle;	
	unsigned long Type;
	unsigned long LocId;
	unsigned long Flags;
};


class CSerialFTDI : public SerialInterface
{
public:
	CSerialFTDI (const char *serialNumber = NULL);
	virtual ~CSerialFTDI();

	// FTDI 디바이스를 검색하고 정보를 얻어오기 위한 함수들
	int ScanFTDIList(const char *name);
	sFtdiInfo *GetFTDIDInfo(const int index);

public:
	// SerialInterface의 interface 함수들
	virtual bool Open();	
	virtual bool Close();
	virtual int  Read (char *buff, int length);
	virtual int  Write (const char *buff, int length);
	virtual void Purge();

	virtual bool SetTimeout (int readTimeout, int writeTimeout, int latencyTimer);
	virtual int  CountRxQueue ();
	virtual bool IsValid () { return _hFtdiOpened != INVALID_HANDLE_VALUE; }
	
	bool SetRxEventNotification (void *hEvent);

private:
	const char* GetErrorString(int error);

private:
	char _serialNumber[32+1];

	void* _hFtdiOpened;	
	vector<sFtdiInfo> _ftdiList;
};
